import asyncio
import re
import time
import xml.etree.ElementTree as ET
from urllib.parse import quote_plus

import aiohttp
import discord
from discord.ext import commands, tasks

import storage.youtube_subscriptions as yt_db
from reo.config.config import BotConfigClass
from reo.console.logging import logger

BotConfig = BotConfigClass()

YT_API = 'https://www.googleapis.com/youtube/v3'
YT_RSS = 'https://www.youtube.com/feeds/videos.xml?channel_id={}'


def _api_key():
    return getattr(BotConfig, 'YOUTUBE_API_KEY', '')


def _extract_channel(value: str):
    value = value.strip()
    m = re.search(r'(?:channel/)(UC[a-zA-Z0-9_-]{20,})', value)
    if m:
        return ('id', m.group(1))
    m = re.search(r'youtube\.com/@([A-Za-z0-9._-]+)', value)
    if m:
        return ('handle', '@' + m.group(1))
    if value.startswith('UC') and len(value) >= 20:
        return ('id', value)
    if value.startswith('@'):
        return ('handle', value)
    return ('search', value)


class YouTube(commands.Cog):
    """YouTube search, video/channel info and live notifications."""

    def __init__(self, bot):
        self.bot = bot
        self.session = None
        self.live_watcher.start()

    def cog_unload(self):
        self.live_watcher.cancel()
        if self.session and not self.session.closed:
            asyncio.create_task(self.session.close())

    async def _session(self):
        if not self.session or self.session.closed:
            self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20))
        return self.session

    async def _request(self, endpoint, params):
        key = _api_key()
        if not key:
            raise RuntimeError('YOUTUBE_API_KEY is not configured in Railway Variables.')
        params = dict(params)
        params['key'] = key
        session = await self._session()
        async with session.get(f'{YT_API}/{endpoint}', params=params) as r:
            data = await r.json(content_type=None)
            if r.status >= 400:
                msg = data.get('error', {}).get('message', f'YouTube API HTTP {r.status}')
                raise RuntimeError(msg)
            return data

    async def resolve_channel(self, value):
        kind, val = _extract_channel(value)
        if kind == 'id':
            data = await self._request('channels', {'part': 'snippet,statistics,contentDetails', 'id': val})
        elif kind == 'handle':
            data = await self._request('channels', {'part': 'snippet,statistics,contentDetails', 'forHandle': val})
        else:
            data = await self._request('search', {'part': 'snippet', 'q': val, 'type': 'channel', 'maxResults': 1})
            items = data.get('items', [])
            if not items:
                return None
            cid = items[0]['snippet']['channelId']
            data = await self._request('channels', {'part': 'snippet,statistics,contentDetails', 'id': cid})
        return data.get('items', [None])[0]

    @commands.hybrid_group(name='youtube', aliases=['yt'], invoke_without_command=True, with_app_command=True,
                            help='YouTube tools: search, video, channel and live notifications')
    async def youtube(self, ctx):
        if ctx.invoked_subcommand is None:
            await ctx.send('Use `/youtube search`, `/youtube video`, `/youtube channel`, `/youtube live` or `/youtube subscribe`.')

    @youtube.command(name='search', with_app_command=True, help='Search YouTube videos')
    async def search(self, ctx, *, query: str):
        await ctx.defer()
        try:
            data = await self._request('search', {'part': 'snippet', 'q': query, 'type': 'video', 'maxResults': 5})
            items = data.get('items', [])
            if not items:
                return await ctx.send('No YouTube results found.')
            lines = []
            for i, item in enumerate(items, 1):
                vid = item['id'].get('videoId')
                sn = item['snippet']
                lines.append(f'**{i}. {sn["title"]}**\n{sn["channelTitle"]} • https://youtu.be/{vid}')
            embed = discord.Embed(title=f'YouTube Search: {query}', description='\n\n'.join(lines), color=discord.Color.red())
            first = items[0]['snippet'].get('thumbnails', {}).get('high', {}).get('url')
            if first:
                embed.set_thumbnail(url=first)
            await ctx.send(embed=embed)
        except Exception as e:
            logger.error(f'YouTube search error: {e}')
            await ctx.send(f'YouTube error: `{e}`')

    @youtube.command(name='video', with_app_command=True, help='Get YouTube video information')
    async def video(self, ctx, video_id: str):
        await ctx.defer()
        video_id = re.search(r'(?:v=|youtu\.be/|/shorts/|/live/)?([A-Za-z0-9_-]{11})', video_id)
        if not video_id:
            return await ctx.send('Invalid YouTube video ID/link.')
        video_id = video_id.group(1)
        try:
            data = await self._request('videos', {'part': 'snippet,statistics,contentDetails,liveStreamingDetails,status', 'id': video_id})
            item = data.get('items', [None])[0]
            if not item:
                return await ctx.send('Video not found.')
            sn, st = item['snippet'], item.get('statistics', {})
            embed = discord.Embed(title=sn['title'], url=f'https://youtu.be/{video_id}', description=sn.get('description', '')[:1000], color=discord.Color.red())
            embed.set_author(name=sn.get('channelTitle', 'YouTube'))
            thumb = sn.get('thumbnails', {}).get('high', {}).get('url')
            if thumb: embed.set_image(url=thumb)
            embed.add_field(name='Views', value=f"{int(st.get('viewCount', 0)):,}", inline=True)
            embed.add_field(name='Likes', value=f"{int(st.get('likeCount', 0)):,}" if 'likeCount' in st else 'Hidden', inline=True)
            embed.add_field(name='Comments', value=f"{int(st.get('commentCount', 0)):,}" if 'commentCount' in st else 'Hidden', inline=True)
            await ctx.send(embed=embed)
        except Exception as e:
            logger.error(f'YouTube video error: {e}')
            await ctx.send(f'YouTube error: `{e}`')

    @youtube.command(name='channel', with_app_command=True, help='Get YouTube channel information')
    async def channel(self, ctx, *, channel: str):
        await ctx.defer()
        try:
            item = await self.resolve_channel(channel)
            if not item:
                return await ctx.send('Channel not found.')
            sn, st = item['snippet'], item.get('statistics', {})
            embed = discord.Embed(title=sn['title'], url=f"https://www.youtube.com/channel/{item['id']}", description=sn.get('description', '')[:1000], color=discord.Color.red())
            avatar = sn.get('thumbnails', {}).get('high', {}).get('url')
            if avatar: embed.set_thumbnail(url=avatar)
            embed.add_field(name='Subscribers', value=f"{int(st.get('subscriberCount', 0)):,}" if not st.get('hiddenSubscriberCount') else 'Hidden')
            embed.add_field(name='Videos', value=f"{int(st.get('videoCount', 0)):,}")
            embed.add_field(name='Views', value=f"{int(st.get('viewCount', 0)):,}")
            await ctx.send(embed=embed)
        except Exception as e:
            logger.error(f'YouTube channel error: {e}')
            await ctx.send(f'YouTube error: `{e}`')

    @youtube.command(name='live', with_app_command=True, help='Check whether a channel is live')
    async def live(self, ctx, *, channel: str):
        await ctx.defer()
        try:
            item = await self.resolve_channel(channel)
            if not item:
                return await ctx.send('Channel not found.')
            cid = item['id']
            data = await self._request('search', {'part': 'snippet', 'channelId': cid, 'eventType': 'live', 'type': 'video', 'maxResults': 1})
            if not data.get('items'):
                return await ctx.send(f'🔴 **{item["snippet"]["title"]}** is not live right now.')
            x = data['items'][0]
            vid = x['id']['videoId']
            await ctx.send(f'🔴 **{x["snippet"]["title"]}** is LIVE now!\nhttps://youtu.be/{vid}')
        except Exception as e:
            logger.error(f'YouTube live error: {e}')
            await ctx.send(f'YouTube error: `{e}`')

    @youtube.command(name='subscribe', with_app_command=True, help='Subscribe this server to live notifications for a channel')
    @commands.has_permissions(manage_guild=True)
    async def subscribe(self, ctx, channel: str, notify_channel: discord.TextChannel = None, role: discord.Role = None):
        await ctx.defer()
        try:
            item = await self.resolve_channel(channel)
            if not item:
                return await ctx.send('Channel not found.')
            target = notify_channel or ctx.channel
            existing = await yt_db.get(guild_id=ctx.guild.id, channel_id=item['id'])
            if existing:
                await yt_db.update(id=existing['id'], notify_channel_id=target.id, role_id=role.id if role else existing.get('role_id'), enabled=True)
            else:
                await yt_db.insert(guild_id=ctx.guild.id, channel_id=item['id'], channel_title=item['snippet']['title'],
                                    channel_url=f'https://www.youtube.com/channel/{item["id"]}', notify_channel_id=target.id,
                                    role_id=role.id if role else None, enabled=True)
            await ctx.send(f'✅ Live notifications enabled for **{item["snippet"]["title"]}** in {target.mention}.')
        except Exception as e:
            logger.error(f'YouTube subscribe error: {e}')
            await ctx.send(f'YouTube error: `{e}`')

    @youtube.command(name='unsubscribe', with_app_command=True, help='Stop live notifications for a channel')
    @commands.has_permissions(manage_guild=True)
    async def unsubscribe(self, ctx, *, channel: str):
        try:
            item = await self.resolve_channel(channel)
            if not item:
                return await ctx.send('Channel not found.')
            await yt_db.delete(guild_id=ctx.guild.id, channel_id=item['id'])
            await ctx.send(f'✅ Notifications removed for **{item["snippet"]["title"]}**.')
        except Exception as e:
            await ctx.send(f'YouTube error: `{e}`')

    @youtube.command(name='subscriptions', with_app_command=True, help='List this server\'s YouTube live subscriptions')
    @commands.has_permissions(manage_guild=True)
    async def subscriptions(self, ctx):
        rows = await yt_db.gets(guild_id=ctx.guild.id, enabled=True)
        if not rows:
            return await ctx.send('No YouTube live notifications are configured.')
        desc = '\n'.join(f'• **{r.get("channel_title", r["channel_id"])}** → <#{r["notify_channel_id"]}>' for r in rows)
        await ctx.send(embed=discord.Embed(title='YouTube Live Notifications', description=desc, color=discord.Color.red()))

    @tasks.loop(minutes=10)
    async def live_watcher(self):
        await self.bot.wait_until_ready()
        try:
            rows = await yt_db.gets(enabled=True)
            by_channel = {}
            for row in rows:
                cid = row.get('channel_id')
                if cid:
                    by_channel.setdefault(cid, []).append(row)

            for cid, channel_rows in by_channel.items():
                try:
                    session = await self._session()
                    async with session.get(YT_RSS.format(cid)) as resp:
                        if resp.status != 200:
                            continue
                        xml = await resp.text()
                    root = ET.fromstring(xml)
                    ns = {'yt': 'http://www.youtube.com/xml/schemas/2015', 'a': 'http://www.w3.org/2005/Atom'}
                    entry = root.find('a:entry', ns)
                    if entry is None:
                        continue
                    vid_node = entry.find('yt:videoId', ns)
                    if vid_node is None:
                        continue
                    vid = vid_node.text

                    data = await self._request('videos', {'part': 'snippet,liveStreamingDetails,status', 'id': vid})
                    item = data.get('items', [None])[0]
                    if not item:
                        continue
                    live_details = item.get('liveStreamingDetails', {})
                    actual_start = live_details.get('actualStartTime')
                    if not actual_start:
                        continue

                    title = item['snippet']['title']
                    thumb = item['snippet'].get('thumbnails', {}).get('high', {}).get('url')
                    for row in channel_rows:
                        if row.get('last_live_id') == vid:
                            continue
                        await yt_db.update(id=row['id'], last_live_id=vid)
                        channel = self.bot.get_channel(int(row['notify_channel_id']))
                        if not channel:
                            continue
                        mention = f'<@&{row["role_id"]}> ' if row.get('role_id') else ''
                        embed = discord.Embed(
                            title='🔴 YouTube Live Now',
                            description=f'{mention}**{title}**\nhttps://youtu.be/{vid}',
                            color=discord.Color.red(),
                        )
                        if thumb:
                            embed.set_image(url=thumb)
                        await channel.send(embed=embed, allowed_mentions=discord.AllowedMentions(roles=True))
                except Exception as channel_error:
                    logger.error(f'YouTube live watcher channel error ({cid}): {channel_error}')
        except Exception as e:
            logger.error(f'YouTube live watcher error: {e}')

    @live_watcher.before_loop
    async def before_live_watcher(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(YouTube(bot))
